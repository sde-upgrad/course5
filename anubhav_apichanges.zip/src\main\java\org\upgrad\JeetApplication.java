package org.upgrad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JeetApplication {

	public static void main(String[] args) {
		SpringApplication.run(JeetApplication.class, args);
	}
}
