insert into movies(id,name,day,description,released,rating) values(1,'Sholay','Monday','Classic','yes',1);
insert into movies(id,name,day,description,released,rating) values(2,'Tomb Raider','Monday','Action','yes',1);
insert into movies(id,name,day,description,released,rating) values(3,'Toby Maguire','Tuesday','Action','no',2);
insert into movies(id,name,day,description,released,rating) values(4,'Infinity','Tuesday','Action','no',2);
insert into movies(id,name,day,description,released,rating) values(5,'Alexander the movie','Tuesday','Action','no',2);

insert into userentity(userid,name,password) values(1,'Rajeev','password');
insert into userentity(userid,name,password) values(2,'Vishal','password');
insert into userentity(userid,name,password) values(3,'Gaurav','password');

insert into shoppingcart(cartid,userid,showid,numberoftickets,cartstring) values(1,1,2,6,'1#1#3#3#3#');
insert into shoppingcart(cartid,userid,showid,numberoftickets,cartstring) values(2,2,1,4,'1#1#3#3#3#');

insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(1,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(2,'English','Kolkata','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(3,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(4,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(5,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(6,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(7,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(8,'English','Delhi','PVR Heights','schindlers list',40,'classic','tomorrow');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(9,'English','Mumbai','PVR Heights','schindlers list',40,'classic','tomorrow');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(10,'English','Mumbai','PVR Heights','schindlers list',40,'classic','tomorrow');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(11,'English','Mumbai','PVR Heights','schindlers list',40,'classic','tomorrow');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(12,'English','Mumbai','PVR Heights','schindlers list',40,'classic','tomorrow');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(13,'English','Mumbai','PVR Heights','schindlers list',40,'classic','tomorrow');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(14,'English','Mumbai','PVR Heights','schindlers list',40,'classic','tomorrow');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(15,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(16,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(17,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(18,'English','Mumbai','PVR Heights','schindlers list',40,'classic','today');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(19,'English','Mumbai','PVR Heights','schindlers list',40,'classic','Tuesday');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(20,'English','Mumbai','PVR Heights','schindlers list',40,'classic','Monday');
insert into shows(showid,language,city,pvrcinema,moviename,availability,description,day) values(21,'English','Mumbai','PVR Heights','schindlers list',40,'classic','Sunday');
