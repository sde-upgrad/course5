package org.upgrad.repository;

import org.springframework.data.repository.CrudRepository;
import org.upgrad.model.Userentity;

public interface UserEntityRepository extends CrudRepository<Userentity, Integer>  {

	
	
}
