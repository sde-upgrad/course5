package org.upgrad.repository;

import org.springframework.data.repository.CrudRepository;
import org.upgrad.model.Shoppingcart;

public interface ShoppingcartRepository extends CrudRepository<Shoppingcart, Integer>  {

}
